import 'package:flutter/material.dart';
import '../data/property.dart';
import 'description.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with TickerProviderStateMixin {
  final List<Property> properties = [
    Property(name: 'Luxury Villa', image: 'assets/image.png', price: 500000, description: 'A stunning villa with a sea view.'),
    Property(name: 'Modern Apartment', image: 'assets/image_1.png', price: 200000, description: 'Stylish apartment in the city center.'),
    Property(name: 'Cozy Cottage', image: 'assets/image_2.png', price: 150000, description: 'A warm and cozy cottage in the countryside.'),
    Property(name: 'Penthouse Suite', image: 'assets/image_3.png', price: 750000, description: 'Luxurious penthouse with a city skyline view.'),
    Property(name: 'Beachfront Bungalow', image: 'assets/image_4.png', price: 600000, description: 'Bungalow located right on the beach.'),
    Property(name: 'Country Farmhouse', image: 'assets/image_5.png', price: 350000, description: 'Spacious farmhouse with acres of land.'),
  ];

  late final List<AnimationController> _controllers;
  late final List<Animation<double>> _animations;

  @override
  void initState() {
    super.initState();
    _controllers = List.generate(
      properties.length,
          (index) => AnimationController(
        duration: const Duration(milliseconds: 1000),
        vsync: this,
      ),
    );
    _animations = _controllers
        .map((controller) => CurvedAnimation(parent: controller, curve: Curves.easeIn))
        .toList();
    for (int i = 0; i < _controllers.length; i++) {
      Future.delayed(Duration(milliseconds: i * 300), () {
        _controllers[i].forward();
      });
    }
  }

  @override
  void dispose() {
    for (final controller in _controllers) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: const Text('Altaf Properties'),
        backgroundColor: Colors.teal[300],
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {},
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: ListView.builder(
            itemCount: properties.length,
            itemBuilder: (context, index) {
              Property property = properties[index];
              return FadeTransition(
                opacity: _animations[index],
                child: Card(
                  elevation: 5,
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(16.0),
                    leading: ClipOval(
                      child: Image.asset(property.image, width: 50, height: 50, fit: BoxFit.cover),
                    ),
                    title: Center(
                      child: Text(
                        property.name,
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ),
                    subtitle: Center(
                      child: Text(
                        'OMR ${property.price}',
                        style: const TextStyle(fontSize: 16, color: Colors.grey),
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Description(property: property),
                        ),
                      );
                    },
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
