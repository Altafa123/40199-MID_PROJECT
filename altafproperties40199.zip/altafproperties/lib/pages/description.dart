import 'package:flutter/material.dart';
import '../data/property.dart';
import 'property_info.dart';

class Description extends StatefulWidget {
  final Property property;
  const Description({super.key, required this.property});

  @override
  _DescriptionState createState() => _DescriptionState();
}

class _DescriptionState extends State<Description> with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(duration: const Duration(seconds: 1), vsync: this);
    _scaleAnimation = CurvedAnimation(parent: _scaleController, curve: Curves.easeIn);
    Future.delayed(const Duration(milliseconds: 500), () {
      _scaleController.forward();
    });
  }

  @override
  void dispose() {
    _scaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.property.name),
        backgroundColor: Colors.teal[300],
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: () {},
          ),
        ],
      ),
      body: Center(
        child: ScaleTransition(
          scale: _scaleAnimation,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(widget.property.image, width: 200, height: 200, fit: BoxFit.cover),
              const SizedBox(height: 20),
              Text(
                widget.property.name,
                style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.black),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              Text(
                widget.property.description,
                style: const TextStyle(fontSize: 20, color: Colors.grey),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => Property_info(property: widget.property),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(backgroundColor: Colors.teal[300]),
                icon: const Icon(Icons.info_outline),
                label: const Text('View More Info'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
